Git repo containing all material for Coursera Course on Introduction to Recommender Systems (https://class.coursera.org/recsys-001/class)
